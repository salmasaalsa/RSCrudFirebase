package erdin.sample.app.rscrudfirebase

class Pasien {
    var nama: String? = null
    var alamat: String? = null
    var umur: String? = null
    var tanggal_lahir: String? = null

    constructor():this("","","","") {

    }

    constructor(nama: String?, alamat: String?, umur: String?, tanggal_lahir: String?) {
        this.nama = nama
        this.alamat = alamat
        this.umur = umur
        this.tanggal_lahir = tanggal_lahir
    }
}