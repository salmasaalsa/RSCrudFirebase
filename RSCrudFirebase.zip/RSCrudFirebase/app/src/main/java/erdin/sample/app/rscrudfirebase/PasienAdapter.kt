package erdin.sample.app.rscrudfirebase

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.ViewGroup

class PasienAdapter(private val pasien: List<Pasien>) : RecyclerView.Adapter<PasienHolder>() {

    override fun onCreateViewHolder(viewGroup: ViewGroup, p1: Int): PasienHolder {
        return PasienHolder(LayoutInflater.from(viewGroup.context).inflate(R.layout.item_main, viewGroup, false))
    }

    override fun getItemCount(): Int = pasien.size

    override fun onBindViewHolder(holder: PasienHolder, position: Int) {
        holder.bindPasien(pasien[position])
    }
}